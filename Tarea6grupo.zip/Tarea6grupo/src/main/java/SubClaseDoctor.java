/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author irapa
 */
public class SubClaseDoctor extends SuperClasePersona {
    private String especialidad;

    public SubClaseDoctor(String nombre, int edad, String genero, String especialidad) {
        super(nombre, edad, genero);
        this.especialidad = especialidad;
    }

    public String getEspecialidad() {
        return especialidad;
    }

    public void setEspecialidad(String especialidad) {
        this.especialidad = especialidad;
    }

    @Override
    public void mostrarInformacion() {
        System.out.println("Doctor: " + getNombre() + ", Edad: " + getEdad() + ", Género: " + getGenero() + ", Especialidad: " + especialidad);
    }
}