/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.tarea6grupo;

/**
 *
 * @author irapa
 */
public class Tarea6grupo {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
